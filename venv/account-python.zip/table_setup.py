import pymysql
import logging

class TableSetup:
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    table_names = ["User", "Account", "Budget", "Goal"]

    @staticmethod
    def setup_tables(rds_host, username, db_password):
        conn = pymysql.connect(rds_host, user=username, passwd=db_password, connect_timeout=5)
        try:
            with conn.cursor as cur:
                cur.execute("CREATE DATABASE rds_poc")
                conn.commit()
                cur.execute("SHOW DATABASES")
                conn.commit()
                TableSetup.logger.info("SUCCESS: Created new DB")
        except pymysql.MySQLError as e:
            TableSetup.logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
            TableSetup.logger.error(e)
            sys.exit()
        finally:
            conn.close()

        conn = pymysql.connect(rds_host, username, db_password, "rds_poc", 5)
        TableSetup.logger.info("SUCCESS: Connection to RDS MySQL database succeeded")

        try:
            with conn.cursor() as cur:
                cur.execute("create table User ( Handle  varchar(255) NOT NULL, Username varchar(255) NOT NULL, "
                            "PRIMARY KEY (Handle))")
                cur.execute('insert into User (Handle, Username) values("dummyHandle", "dummy111")')
                # cur.execute('insert into Employee (EmpID, Name) values(2, "Bob")')
                # cur.execute('insert into Employee (EmpID, Name) values(3, "Mary")')
                conn.commit()
                cur.execute("select * from User")
                for row in cur:
                    item_count += 1
                    TableSetup.logger.info(row)
                    # print(row)
                conn.commit()
        except pymysql.MySQLError as e:
            TableSetup.logger.error("ERROR: Unexpected error when performing db actions")
            TableSetup.logger.error(e)
        finally:
            conn.close()

        return "Added %d items from RDS MySQL table" % (item_count)

