
var mysql = require('mysql');
var connection = mysql.createConnection({
    host: process.env['ENDPOINT'],
    user: process.env['USERNAME'],
    password: process.env['PASSWORD'],
    database: process.env['DATABASE_NAME'],
});
// console.log(connection);
exports.handler = (event, context, callback) => {
    connection.query('show tables', function (error, results, fields) {
        if (error) {
            connection.destroy();
            throw error;
        } else {
            // connected!
            console.log(results);
            callback(error, results);
            connection.end(function (err) { callback(err, results);});
        }
    });
};
